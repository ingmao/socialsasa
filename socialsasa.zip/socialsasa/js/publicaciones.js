// JavaScript Document
$(document).ready(function(){

$("#compartir").click(function(){
	 	$.post("publicacion.php",{id_users:$('#id_users').val(),publicacion:$("#message").val()},function(data){
						window.location.replace("index.php");
			});
	});
	
});

function comentario(id){
	alert($('#message-coment-'+id).val())
	$(document).ready(function(){
	$.post("modelos/comentario.php",{id_users:$('#id_users').val(),id_publicacion:id,comentario:$('#message-coment-'+id).val()},function(data){
						window.location.replace("index.php");
			});
	});
	
	}