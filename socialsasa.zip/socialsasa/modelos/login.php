<?php
session_start();
require('../clases/clasemetodos.php');
$objeto=new Clasemetodos;
if(isset($_POST['login'])){
	
	$result=$objeto->consultarlogin(array($_POST['username']));
	if(!empty($result) && count($result)>0){
			if(password_verify($_POST['password'], $result[2])){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $result[0];
                            $_SESSION["nombre"] = $result[3];                            
                            
                            // Redirect user to welcome page
                            header("location: ../index.php");
                        } else{
                            // Display an error message if password is not valid
                            $password_err = "The password you entered was not valid.";
							echo "<script language='JavaScript'> alert('su contraseña no es valida');
								setTimeout(window.location.replace('../login.php'), 1000);
								</script>";
							//header("location: ../login.php");
                        }
	}else{
				echo "<script language='JavaScript'> alert('su usuario o contraseña no sonvalidos');
								setTimeout(window.location.replace('../login.php'), 1000);  
				</script>";
		
		}
	
	
	
	}


?>