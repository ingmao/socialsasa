<?php 

require('../clases/clasemetodos.php');
$objeto=new Clasemetodos;

if(isset($_POST['comentario'])){
	
	if($objeto->insertcomentario(array(htmlspecialchars(trim($_POST["id_users"])),htmlspecialchars(trim($_POST['id_publicacion'])),htmlspecialchars(trim($_POST['comentario']))))==true){
		
		header ("Location: ../index.php");
		}else{
			
			echo "error";
			
			} 
	
	}

?>