<?php

require('../clases/clasemetodos.php');
$objeto=new Clasemetodos;

if(isset($_POST['guardar'])){
	
	if($objeto->insertusuarios(array(htmlspecialchars(trim($_POST['username'])),htmlspecialchars(trim($_POST['email'])),htmlspecialchars(trim($_POST['password']))))==true){
		
		header ("Location: ../login.php");
		}else{
			
			echo "error";
			
			} 
	
	}

?>