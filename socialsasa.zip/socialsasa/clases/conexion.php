<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of conexion
 *
 * @author ingmao
 */
class DBManager{
	var $conect;
    var $BaseDatos;
	var $Servidor;
	var $Usuario;
	var $Clave;
	function __construct(){
		$this->BaseDatos = "socialsasa";
		$this->Servidor = "localhost";
		$this->Usuario = "root";
		$this->Clave = "";
	}

	 function conectar() {
		if(!($con=@mysqli_connect($this->Servidor,$this->Usuario,$this->Clave,$this->BaseDatos))){
			echo"<h1> [:(] Error al conectar a la base de datos</h1>";	
			exit();
		}
		if (!@mysqli_select_db($con,$this->BaseDatos)){
			echo "<h1> [:(] Error al seleccionar la base de datos</h1>";  
			exit();
		}
		$this->conect=$con;
		return true;	
	}
	
	
}
