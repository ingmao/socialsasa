<?php
include_once("conexion.php");

class Clasemetodos{
 //constructor	
 	var $con;
function __construct(){
	$this->con=new DBManager;
	}

	
	
	
	#CREAR PUBLICACIÓN
	function isertarpublicacion($campos){//print_r($campos);die();
		if($this->con->conectar()==true){
			
			return mysqli_query($this->con->conect,"INSERT INTO publicacion (id_users,publicacion,created_at) VALUES ('".$campos[0]."', '".$campos[1]."','".date("Y-m-d H:i:s")."')");
		}
	}
	#Registro de usuarios
	function insertusuarios($campos){
			if($this->con->conectar()==true){
				$campos[2]=password_hash($campos[2], PASSWORD_DEFAULT);
					return mysqli_query($this->con->conect,"INSERT INTO users (nombre,email,password,created_at) VALUES ('".$campos[0]."', '".$campos[1]."','".$campos[2]."','".date("Y-m-d H:i:s")."')");
			}
		
		}
		#logueo de usuarios
		function consultarlogin($campos){
				if($this->con->conectar()==true){
					$sql=mysqli_query($this->con->conect,"SELECT id,email,password,nombre FROM users where email='".$campos[0]."'");
					
					return mysqli_fetch_array($sql,MYSQLI_NUM);
				}
			
			
			}
			#consultar 	articulos
			function consultararticulos(){
				
				if($this->con->conectar()==true){
					$sql=mysqli_query($this->con->conect,"SELECT p.*,u.nombre FROM publicacion as p inner join users as u on u.id=p.id_users order by p.id desc");
					
					return $sql;
				}
				
				}
				#consultar articulos por usuarios
				function consultararticulosusers($id){
							if($this->con->conectar()==true){
								$sql=mysqli_query($this->con->conect,"SELECT * FROM publicacion as p inner join users as u on u.id=p.id_users where p.id_users='".$id."' order by p.id desc");
					
								return $sql;
							}
					}
					#consultar articulo por un usuario
					function consultarusers($id){
						if($this->con->conectar()==true){
								$sql=mysqli_query($this->con->conect,"SELECT u.id,u.nombre FROM publicacion as p inner join users as u on u.id=p.id_users where p.id_users <> '".$id."' group by u.id order by p.id desc");
					
								return $sql;
							}
						
						
						}
						#registrar comentario
						function insertcomentario($campos){
							
							if($this->con->conectar()==true){
			
									return mysqli_query($this->con->conect,"INSERT INTO  comentarios_publicacion (id_users,id_publicacion,comentario,created_at) VALUES ('".$campos[0]."', '".$campos[1]."','".$campos[2]."','".date("Y-m-d H:i:s")."')");
								}
							
							
							}
					#consultar comentarios
					function consultarcomentartios($id){
						if($this->con->conectar()==true){
								$sql=mysqli_query($this->con->conect,"SELECT u.id,u.nombre,c.comentario FROM `comentarios_publicacion` as c inner join `users` as u on u.id=c.id_users WHERE c.comentario <> '' and c.id_publicacion=".$id." order by c.id desc");
					
								return $sql;
							}
						
						
						}		

	
}
?>